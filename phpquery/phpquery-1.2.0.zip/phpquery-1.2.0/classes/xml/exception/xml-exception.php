<?php
/**
 * This file contains the XmlException class.
 * 
 * PHP Version 5.3
 * 
 * @category XML
 * @package  Xml
 * @author   Gonzalo Chumillas <gonzalo@soloproyectos.com>
 * @license  https://raw.github.com/soloproyectos/core/master/LICENSE BSD 2-Clause License
 * @link     https://github.com/soloproyectos/core
 */
namespace com\soloproyectos\core\xml\exception;
use Exception;

/**
 * Class XmlException.
 * 
 * @category XML
 * @package  Xml
 * @author   Gonzalo Chumillas <gonzalo@soloproyectos.com>
 * @license  https://raw.github.com/soloproyectos/core/master/LICENSE BSD 2-Clause License
 * @link     https://github.com/soloproyectos/core
 */
class XmlException extends Exception
{
    
}
